package com.example.personalprofile;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class Read_my_reviews extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_read_my_reviews);
    }
}